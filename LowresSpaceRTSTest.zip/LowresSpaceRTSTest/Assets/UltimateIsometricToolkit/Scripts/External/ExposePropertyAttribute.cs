﻿using System;

namespace Assets.UltimateIsometricToolkit.Scripts.External {
	[AttributeUsage(AttributeTargets.Property)]
	public class ExposePropertyAttribute : Attribute {
	}
}